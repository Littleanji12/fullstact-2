#!/usr/bin/env bash
cd backend || exit
npm install
[ -f .env ] || cp .env.example .env
npm run dev
