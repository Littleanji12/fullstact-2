# NoteKart - Amazon Style Secure Notes App

This project is a separated full-stack app based on the uploaded notes API.

## What is included

- `frontend/` - React + Vite Amazon-style UI
- `backend/` - Node.js + Express + MongoDB API
- JWT authentication
- Register and login
- Create, read, update, delete notes
- Categories: Study, Health, Spiritual, Work, Shopping, General
- Search, filter, sort, pin notes

## Folder structure

```text
amazon-notes-fullstack/
  backend/
    models/
    routes/
    middleware/
    server.js
    package.json
    .env.example
  frontend/
    src/
    package.json
    .env.example
```

## Requirements

Install these first:

- Node.js 18 or higher
- MongoDB Compass / local MongoDB server OR MongoDB Atlas
- VS Code

## Backend setup

Open terminal:

```bash
cd backend
npm install
```

Create your backend `.env` file:

```bash
copy .env.example .env
```

On Mac/Linux use:

```bash
cp .env.example .env
```

For local MongoDB, keep this in `.env`:

```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/amazon_notes_db
JWT_SECRET=replace_this_with_a_long_secret_key
FRONTEND_URL=http://localhost:5173
```

For MongoDB Atlas, replace `MONGO_URI` with your Atlas connection string:

```env
MONGO_URI=mongodb+srv://USERNAME:PASSWORD@cluster0.xxxxx.mongodb.net/amazon_notes_db
```

Start backend:

```bash
npm run dev
```

You should see:

```text
MongoDB Connected
Server running on http://localhost:5000
```

## Frontend setup

Open a second terminal:

```bash
cd frontend
npm install
```

Create your frontend `.env` file:

```bash
copy .env.example .env
```

On Mac/Linux use:

```bash
cp .env.example .env
```

Keep this value:

```env
VITE_API_URL=http://localhost:5000/api
```

Start frontend:

```bash
npm run dev
```

Open this in browser:

```text
http://localhost:5173
```

## How to use

1. Register a new username and password.
2. Login.
3. Add notes using title, content, category and priority.
4. Search notes from the top search bar.
5. Filter notes using the category dropdown or left sidebar.
6. Edit, delete or pin notes from each card.

## Common errors and fixes

### MongoDB connection failed

Use local MongoDB:

```env
MONGO_URI=mongodb://127.0.0.1:27017/amazon_notes_db
```

Or if using Atlas:

- Check username and password.
- Add your IP in Atlas Network Access.
- Make sure database user has read/write permission.

### Frontend cannot connect to backend

Check backend is running on port 5000 and frontend `.env` has:

```env
VITE_API_URL=http://localhost:5000/api
```

### Port already in use

Change `PORT=5000` in backend `.env` to another port like `5001`, then also update frontend `.env`:

```env
VITE_API_URL=http://localhost:5001/api
```
