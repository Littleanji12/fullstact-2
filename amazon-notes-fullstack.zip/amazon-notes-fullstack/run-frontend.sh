#!/usr/bin/env bash
cd frontend || exit
npm install
[ -f .env ] || cp .env.example .env
npm run dev
