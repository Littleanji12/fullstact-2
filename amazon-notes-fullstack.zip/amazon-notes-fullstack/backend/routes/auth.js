const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const auth = require('../middleware/auth');

const router = express.Router();

router.post('/register', async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }

    if (password.length < 6) {
      return res.status(400).json({ message: 'Password must be at least 6 characters' });
    }

    const existingUser = await User.findOne({ username: username.trim() });
    if (existingUser) {
      return res.status(409).json({ message: 'Username already exists' });
    }

    const hash = await bcrypt.hash(password, 10);
    const user = await User.create({ username: username.trim(), password: hash });

    const token = jwt.sign({ id: user._id, username: user.username }, process.env.JWT_SECRET || 'dev_secret_key', { expiresIn: '7d' });

    return res.status(201).json({
      token,
      user: { id: user._id, username: user.username }
    });
  } catch (error) {
    return res.status(500).json({ message: 'Registration failed', error: error.message });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }

    const user = await User.findOne({ username: username.trim() });
    if (!user) {
      return res.status(400).json({ message: 'User not found' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Wrong password' });
    }

    const token = jwt.sign({ id: user._id, username: user.username }, process.env.JWT_SECRET || 'dev_secret_key', { expiresIn: '7d' });

    return res.json({
      token,
      user: { id: user._id, username: user.username }
    });
  } catch (error) {
    return res.status(500).json({ message: 'Login failed', error: error.message });
  }
});

router.get('/me', auth, async (req, res) => {
  return res.json({ user: { id: req.user.id, username: req.user.username } });
});

module.exports = router;
