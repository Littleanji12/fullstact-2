const express = require('express');
const mongoose = require('mongoose');
const Note = require('../models/Note');
const auth = require('../middleware/auth');

const router = express.Router();

router.get('/', auth, async (req, res) => {
  try {
    const { category = 'All', search = '', sort = 'newest' } = req.query;
    const query = { userId: req.user.id };

    if (category !== 'All') {
      query.category = category;
    }

    if (search.trim()) {
      query.$or = [
        { title: { $regex: search.trim(), $options: 'i' } },
        { content: { $regex: search.trim(), $options: 'i' } },
        { category: { $regex: search.trim(), $options: 'i' } }
      ];
    }

    const sortMap = {
      newest: { pinned: -1, createdAt: -1 },
      oldest: { pinned: -1, createdAt: 1 },
      priority: { pinned: -1, priority: -1, createdAt: -1 }
    };

    const notes = await Note.find(query).sort(sortMap[sort] || sortMap.newest);
    return res.json(notes);
  } catch (error) {
    return res.status(500).json({ message: 'Could not fetch notes', error: error.message });
  }
});

router.post('/', auth, async (req, res) => {
  try {
    const { title, content, category, priority, pinned } = req.body;

    if (!title || !content) {
      return res.status(400).json({ message: 'Title and content are required' });
    }

    const note = await Note.create({
      userId: req.user.id,
      title,
      content,
      category: category || 'General',
      priority: priority || 'Medium',
      pinned: Boolean(pinned)
    });

    return res.status(201).json(note);
  } catch (error) {
    return res.status(500).json({ message: 'Could not create note', error: error.message });
  }
});

router.put('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ message: 'Invalid note id' });
    }

    const allowed = ['title', 'content', 'category', 'priority', 'pinned'];
    const updates = {};
    allowed.forEach((field) => {
      if (req.body[field] !== undefined) updates[field] = req.body[field];
    });

    const note = await Note.findOneAndUpdate(
      { _id: id, userId: req.user.id },
      updates,
      { new: true, runValidators: true }
    );

    if (!note) {
      return res.status(404).json({ message: 'Note not found' });
    }

    return res.json(note);
  } catch (error) {
    return res.status(500).json({ message: 'Could not update note', error: error.message });
  }
});

router.delete('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ message: 'Invalid note id' });
    }

    const note = await Note.findOneAndDelete({ _id: id, userId: req.user.id });

    if (!note) {
      return res.status(404).json({ message: 'Note not found' });
    }

    return res.json({ message: 'Note deleted' });
  } catch (error) {
    return res.status(500).json({ message: 'Could not delete note', error: error.message });
  }
});

module.exports = router;
