const mongoose = require('mongoose');

const noteSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  title: {
    type: String,
    required: true,
    trim: true,
    maxlength: 80
  },
  content: {
    type: String,
    required: true,
    trim: true
  },
  category: {
    type: String,
    default: 'General',
    enum: ['Study', 'Health', 'Spiritual', 'Work', 'Shopping', 'General']
  },
  priority: {
    type: String,
    default: 'Medium',
    enum: ['Low', 'Medium', 'High']
  },
  pinned: {
    type: Boolean,
    default: false
  }
}, { timestamps: true });

noteSchema.index({ title: 'text', content: 'text', category: 'text' });

module.exports = mongoose.model('Note', noteSchema);
