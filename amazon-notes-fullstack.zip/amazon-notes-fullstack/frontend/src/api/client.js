const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export function getToken() {
  return localStorage.getItem('notekart_token');
}

export function setSession(token, user) {
  localStorage.setItem('notekart_token', token);
  localStorage.setItem('notekart_user', JSON.stringify(user));
}

export function clearSession() {
  localStorage.removeItem('notekart_token');
  localStorage.removeItem('notekart_user');
}

export function getSavedUser() {
  try {
    return JSON.parse(localStorage.getItem('notekart_user'));
  } catch {
    return null;
  }
}

export async function api(path, options = {}) {
  const token = getToken();
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {})
  };

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.message || 'Request failed');
  }

  return data;
}
