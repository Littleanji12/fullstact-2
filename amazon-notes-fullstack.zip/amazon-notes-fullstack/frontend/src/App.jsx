import { useEffect, useMemo, useState } from 'react';
import { api, clearSession, getSavedUser, getToken } from './api/client';
import AuthPanel from './components/AuthPanel';
import Header from './components/Header';
import NoteForm from './components/NoteForm';
import NoteCard from './components/NoteCard';
import Sidebar from './components/Sidebar';

export default function App() {
  const [user, setUser] = useState(getSavedUser());
  const [notes, setNotes] = useState([]);
  const [allNotes, setAllNotes] = useState([]);
  const [category, setCategory] = useState('All');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState('newest');
  const [editingNote, setEditingNote] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const isLoggedIn = Boolean(user && getToken());

  async function fetchNotes() {
    if (!getToken()) return;
    setLoading(true);
    setError('');
    try {
      const query = new URLSearchParams({ category, search, sort });
      const data = await api(`/notes?${query.toString()}`);
      setNotes(data);

      const allData = await api('/notes?category=All&sort=newest');
      setAllNotes(allData);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchNotes();
  }, [category, search, sort, user]);

  async function saveNote(form) {
    setError('');
    try {
      if (editingNote) {
        await api(`/notes/${editingNote._id}`, {
          method: 'PUT',
          body: JSON.stringify(form)
        });
        setEditingNote(null);
      } else {
        await api('/notes', {
          method: 'POST',
          body: JSON.stringify(form)
        });
      }
      fetchNotes();
    } catch (err) {
      setError(err.message);
    }
  }

  async function deleteNote(id) {
    const ok = window.confirm('Delete this note?');
    if (!ok) return;

    try {
      await api(`/notes/${id}`, { method: 'DELETE' });
      fetchNotes();
    } catch (err) {
      setError(err.message);
    }
  }

  async function togglePin(note) {
    try {
      await api(`/notes/${note._id}`, {
        method: 'PUT',
        body: JSON.stringify({ pinned: !note.pinned })
      });
      fetchNotes();
    } catch (err) {
      setError(err.message);
    }
  }

  function logout() {
    clearSession();
    setUser(null);
    setNotes([]);
    setAllNotes([]);
  }

  const stats = useMemo(() => ({
    total: allNotes.length,
    pinned: allNotes.filter((note) => note.pinned).length,
    high: allNotes.filter((note) => note.priority === 'High').length
  }), [allNotes]);

  if (!isLoggedIn) {
    return <AuthPanel onAuth={setUser} />;
  }

  return (
    <div>
      <Header
        user={user}
        search={search}
        setSearch={setSearch}
        category={category}
        setCategory={setCategory}
        onLogout={logout}
      />

      <section className="hero-banner">
        <div>
          <span className="deal-tag">Productivity Deal</span>
          <h2>Manage notes like an online store dashboard</h2>
          <p>Search, categorize, pin, edit and delete your notes using a clean Amazon-inspired interface.</p>
        </div>
        <div className="hero-stats">
          <div><strong>{stats.total}</strong><span>Total Notes</span></div>
          <div><strong>{stats.pinned}</strong><span>Pinned</span></div>
          <div><strong>{stats.high}</strong><span>High Priority</span></div>
        </div>
      </section>

      <main className="layout">
        <Sidebar category={category} setCategory={setCategory} notes={allNotes} />

        <section className="content-area">
          <NoteForm
            onSubmit={saveNote}
            editingNote={editingNote}
            onCancelEdit={() => setEditingNote(null)}
          />

          <div className="toolbar">
            <div>
              <h2>Results</h2>
              <p>{loading ? 'Loading notes...' : `${notes.length} note(s) found`}</p>
            </div>
            <select value={sort} onChange={(e) => setSort(e.target.value)}>
              <option value="newest">Sort by newest</option>
              <option value="oldest">Sort by oldest</option>
              <option value="priority">Sort by priority</option>
            </select>
          </div>

          {error && <div className="error-box wide">{error}</div>}

          <div className="notes-grid">
            {!loading && notes.length === 0 && (
              <div className="empty-state">
                <h3>No notes found</h3>
                <p>Add a note or change the search/category filter.</p>
              </div>
            )}

            {notes.map((note) => (
              <NoteCard
                key={note._id}
                note={note}
                onEdit={setEditingNote}
                onDelete={deleteNote}
                onTogglePin={togglePin}
              />
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
