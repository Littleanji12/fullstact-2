const categoryList = [
  { name: 'All', icon: '🏬' },
  { name: 'Study', icon: '📘' },
  { name: 'Health', icon: '💪' },
  { name: 'Spiritual', icon: '🕉️' },
  { name: 'Work', icon: '💼' },
  { name: 'Shopping', icon: '🛒' },
  { name: 'General', icon: '📝' }
];

export default function Sidebar({ category, setCategory, notes }) {
  const countByCategory = (name) => {
    if (name === 'All') return notes.length;
    return notes.filter((note) => note.category === name).length;
  };

  return (
    <aside className="sidebar">
      <h3>Departments</h3>
      {categoryList.map((item) => (
        <button
          key={item.name}
          className={category === item.name ? 'active' : ''}
          onClick={() => setCategory(item.name)}
        >
          <span>{item.icon} {item.name}</span>
          <small>{countByCategory(item.name)}</small>
        </button>
      ))}

      <div className="offer-box">
        <strong>NoteKart Tip</strong>
        <p>Use high priority + pinned for viva, exam and project deadlines.</p>
      </div>
    </aside>
  );
}
