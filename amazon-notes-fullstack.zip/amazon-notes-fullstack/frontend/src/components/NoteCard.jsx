export default function NoteCard({ note, onEdit, onDelete, onTogglePin }) {
  const date = new Date(note.createdAt).toLocaleDateString(undefined, {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });

  return (
    <article className="note-card">
      <div className="note-image-area">
        <span className="note-emoji">{note.category === 'Study' ? '📘' : note.category === 'Health' ? '💪' : note.category === 'Spiritual' ? '🕉️' : note.category === 'Shopping' ? '🛒' : note.category === 'Work' ? '💼' : '📝'}</span>
        {note.pinned && <span className="best-seller">Pinned</span>}
      </div>

      <div className="note-body">
        <div className="rating-line">
          <span>★★★★★</span>
          <small>{note.priority} priority</small>
        </div>

        <h3>{note.title}</h3>
        <p>{note.content}</p>

        <div className="price-line">
          <span className="currency">#</span>
          <strong>{note.category}</strong>
        </div>
        <span className="delivery-line">Created on {date}</span>

        <div className="card-actions">
          <button onClick={() => onTogglePin(note)}>{note.pinned ? 'Unpin' : 'Pin'}</button>
          <button onClick={() => onEdit(note)}>Edit</button>
          <button className="danger" onClick={() => onDelete(note._id)}>Delete</button>
        </div>
      </div>
    </article>
  );
}
