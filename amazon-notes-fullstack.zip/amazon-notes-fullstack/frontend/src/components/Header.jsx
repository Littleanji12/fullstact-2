const categories = ['All', 'Study', 'Health', 'Spiritual', 'Work', 'Shopping', 'General'];

export default function Header({ user, search, setSearch, category, setCategory, onLogout }) {
  return (
    <>
      <header className="top-header">
        <div className="brand-block">
          <div className="brand-smile">⌣</div>
          <div>
            <h1>NoteKart</h1>
            <span>Amazon-style secure notes</span>
          </div>
        </div>

        <div className="location-chip">
          <span>Deliver to</span>
          <strong>{user?.username || 'Student'}</strong>
        </div>

        <div className="search-bar">
          <select value={category} onChange={(e) => setCategory(e.target.value)}>
            {categories.map((item) => (
              <option value={item} key={item}>{item}</option>
            ))}
          </select>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search your notes, categories, tasks..."
          />
          <button type="button">🔍</button>
        </div>

        <div className="account-box">
          <span>Hello, {user?.username || 'user'}</span>
          <strong>Account & Lists</strong>
        </div>

        <button className="logout-btn" onClick={onLogout}>Logout</button>
      </header>

      <nav className="sub-nav">
        <span>☰ All</span>
        <span>Today's Notes</span>
        <span>Pinned</span>
        <span>High Priority</span>
        <span>Study Deals</span>
        <span>Productivity</span>
      </nav>
    </>
  );
}
