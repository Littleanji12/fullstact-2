import { useEffect, useState } from 'react';

const emptyForm = {
  title: '',
  content: '',
  category: 'Study',
  priority: 'Medium',
  pinned: false
};

export default function NoteForm({ onSubmit, editingNote, onCancelEdit }) {
  const [form, setForm] = useState(emptyForm);

  useEffect(() => {
    if (editingNote) {
      setForm({
        title: editingNote.title,
        content: editingNote.content,
        category: editingNote.category,
        priority: editingNote.priority,
        pinned: editingNote.pinned
      });
    } else {
      setForm(emptyForm);
    }
  }, [editingNote]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((prev) => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(form);
    if (!editingNote) setForm(emptyForm);
  };

  return (
    <form className="note-form" onSubmit={handleSubmit}>
      <div className="form-title-row">
        <div>
          <h2>{editingNote ? 'Update your note' : 'Add a new note'}</h2>
          <p>Looks like a product card, works like your personal notebook.</p>
        </div>
        {editingNote && <button type="button" className="link-btn" onClick={onCancelEdit}>Cancel edit</button>}
      </div>

      <input
        name="title"
        value={form.title}
        onChange={handleChange}
        placeholder="Note title"
        required
      />

      <textarea
        name="content"
        value={form.content}
        onChange={handleChange}
        placeholder="Write your note details..."
        rows="4"
        required
      />

      <div className="form-grid">
        <select name="category" value={form.category} onChange={handleChange}>
          <option>Study</option>
          <option>Health</option>
          <option>Spiritual</option>
          <option>Work</option>
          <option>Shopping</option>
          <option>General</option>
        </select>

        <select name="priority" value={form.priority} onChange={handleChange}>
          <option>Low</option>
          <option>Medium</option>
          <option>High</option>
        </select>
      </div>

      <label className="pin-row">
        <input type="checkbox" name="pinned" checked={form.pinned} onChange={handleChange} />
        Pin this note at the top
      </label>

      <button className="buy-now-btn">{editingNote ? 'Save Changes' : 'Add to Notes'}</button>
    </form>
  );
}
